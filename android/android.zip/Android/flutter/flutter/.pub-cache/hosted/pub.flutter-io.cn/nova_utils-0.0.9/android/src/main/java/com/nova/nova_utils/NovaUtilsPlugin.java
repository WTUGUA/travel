package com.nova.nova_utils;

import android.content.Context;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/**
 * NovaUtilsPlugin
 */
public class NovaUtilsPlugin implements MethodCallHandler {

    private static Context context;

    /**
     * Plugin registration.
     */
    public static void registerWith(Registrar registrar) {
        final MethodChannel channel = new MethodChannel(registrar.messenger(), "nova_utils");
        context = registrar.activity();
        channel.setMethodCallHandler(new NovaUtilsPlugin());
    }

    @Override
    public void onMethodCall(MethodCall call, Result result) {
        if (call.method.equals("getPlatformVersion")) {
            result.success("Android " + android.os.Build.VERSION.RELEASE);
        } else if (call.method.equals("launchMarket")) {
            CommonUtils.toMarket(context);
        } else {
            result.notImplemented();
        }
    }
}
