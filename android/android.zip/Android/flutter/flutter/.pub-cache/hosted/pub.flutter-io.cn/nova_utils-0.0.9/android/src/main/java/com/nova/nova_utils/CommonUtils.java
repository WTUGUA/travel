package com.nova.nova_utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class CommonUtils {


    public static void toMarket(Context mContext){
        Intent localIntent = new Intent("android.intent.action.VIEW");
        localIntent.setData(Uri.parse("market://details?id=" + mContext.getPackageName()));
        mContext.startActivity(localIntent);
    }
}
