package com.jarvan.fluwx.constant;

public class WeChatPluginImageSchema {
    public static final String SCHEMA_ASSETS = "assets://";
    public static final String SCHMEA_HTTP = "http://";
    public static final String SCHMEA_HTTPS = "https://";
    public static final String SCHEMA_FILE = "file://";
    public static final String SCHEMA_CONTENT = "content://";
}
